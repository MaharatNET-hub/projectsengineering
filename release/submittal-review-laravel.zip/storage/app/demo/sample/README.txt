Put the sample submittal here as submittal.pdf (by FTP). Never commit it.
